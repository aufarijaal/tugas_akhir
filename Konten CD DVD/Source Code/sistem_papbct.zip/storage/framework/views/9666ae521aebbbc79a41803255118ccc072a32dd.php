<?php $__env->startSection('slot'); ?>
    <div class="login-wrapper w-full flex justify-center lg:items-center h-full">
        <div class="wrapper flex flex-col gap-10 lg:bg-white lg:border-2 lg:border-stone-300/40 w-max h-max p-6 rounded-xl">
            <div class="w-full">
                <form action="<?php echo e(route('register-owner')); ?>" method="post" class="flex flex-col gap-4 items-center">
                    <?php echo csrf_field(); ?>
                    <a href="<?php echo e(url('/')); ?>">
                        <img src="<?php echo e(asset('icons/icon-72x72.png')); ?>" class="scale-90">
                    </a>
                    <h1 class="text-2xl tracking-wide mb-10 lg:mb-0" style="font-weight: 700; font-variation-settings: 'wght' 700">REGISTER OWNER</h1>
                    <div class="flex flex-col gap-2">
                        <label for="username_owner">Username</label>
                        <?php if (isset($component)) { $__componentOriginalef9fe90827f80191dcf8af8db4c01e3441ebe337 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\FillSpace::class, []); ?>
<?php $component->withName('fill-space'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
                            <input required id="username_owner" class="h-10 w-68 pl-2 outline-none focus:border-sky-300 border-2 border-zinc-200 bg-zinc-200 rounded-md" type="text" name="username_owner" placeholder="Masukkan username">
                         <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalef9fe90827f80191dcf8af8db4c01e3441ebe337)): ?>
<?php $component = $__componentOriginalef9fe90827f80191dcf8af8db4c01e3441ebe337; ?>
<?php unset($__componentOriginalef9fe90827f80191dcf8af8db4c01e3441ebe337); ?>
<?php endif; ?>
                    </div>
                    <div class="flex flex-col gap-2">
                        <?php if (isset($component)) { $__componentOriginalee2301e75258d546ded542aad400c79e399d91cc = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\HelpTooltip::class, []); ?>
<?php $component->withName('help-tooltip'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
                            <label for="machineid">ID Mesin</label>
                         <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalee2301e75258d546ded542aad400c79e399d91cc)): ?>
<?php $component = $__componentOriginalee2301e75258d546ded542aad400c79e399d91cc; ?>
<?php unset($__componentOriginalee2301e75258d546ded542aad400c79e399d91cc); ?>
<?php endif; ?>
                        <?php if (isset($component)) { $__componentOriginal3844197888b5b4ca19a35b1dc5e2512383c87dee = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\PeekPassword::class, []); ?>
<?php $component->withName('peek-password'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
                            <input required id="machineid" class="h-10 w-68 pl-2 outline-none focus:border-sky-300 border-2 border-zinc-200 bg-zinc-200 rounded-md" type="password" name="machineid" placeholder="Masukkan id mesin">
                         <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal3844197888b5b4ca19a35b1dc5e2512383c87dee)): ?>
<?php $component = $__componentOriginal3844197888b5b4ca19a35b1dc5e2512383c87dee; ?>
<?php unset($__componentOriginal3844197888b5b4ca19a35b1dc5e2512383c87dee); ?>
<?php endif; ?>
                    </div>
                    <div class="flex flex-col gap-2">
                        <label for="password_owner">Kata sandi</label>
                        <?php if (isset($component)) { $__componentOriginal3844197888b5b4ca19a35b1dc5e2512383c87dee = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\PeekPassword::class, []); ?>
<?php $component->withName('peek-password'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
                            <input required id="password_owner" class="h-10 w-68 pl-2 outline-none focus:border-sky-300 border-2 border-zinc-200 bg-zinc-200 rounded-md" type="password" name="password_owner" placeholder="Masukkan kata sandi">
                         <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal3844197888b5b4ca19a35b1dc5e2512383c87dee)): ?>
<?php $component = $__componentOriginal3844197888b5b4ca19a35b1dc5e2512383c87dee; ?>
<?php unset($__componentOriginal3844197888b5b4ca19a35b1dc5e2512383c87dee); ?>
<?php endif; ?>
                    </div>
                    <div class="flex flex-col gap-2">
                        <label for="confirm_password_owner">Konfirmasi kata sandi</label>
                        <?php if (isset($component)) { $__componentOriginal3844197888b5b4ca19a35b1dc5e2512383c87dee = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\PeekPassword::class, []); ?>
<?php $component->withName('peek-password'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
                            <input required id="confirm_password_owner" class="h-10 w-68 pl-2 outline-none focus:border-sky-300 border-2 border-zinc-200 bg-zinc-200 rounded-md" type="password" name="confirm_password_owner" placeholder="Masukkan ulang kata sandi">
                         <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal3844197888b5b4ca19a35b1dc5e2512383c87dee)): ?>
<?php $component = $__componentOriginal3844197888b5b4ca19a35b1dc5e2512383c87dee; ?>
<?php unset($__componentOriginal3844197888b5b4ca19a35b1dc5e2512383c87dee); ?>
<?php endif; ?>
                    </div>
                    <?php if($errors->any()): ?>
                        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <p class="text-xs text-red-500" id="error-machine-id"><?php echo e($error); ?></p>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php endif; ?>
                    <button type="submit" class="active:bg-sky-300 active:text-sky-600 bg-sky-200 text-sky-500 font-bold w-36 h-10 rounded-lg">Register</button>
                    
                    <p class="text-xs ">Sudah punya akun? <a class="text-sky-500" href="<?php echo e(route('login')); ?>">login</a></p>
                </form>
            </div>
        </div>
</div>
<?php $__env->startPush('scripts'); ?>
    <script>
    tippy('#help-id-mesin', {
        content: '<strong style="color: #F5C642;">ID mesin</strong> digunakan untuk menghubungkan akun Anda dengan mesin pembuat bubuk cangkang telur anda. <br><br>Misalnya Anda atau pekerja yang anda punya ingin menyalakan mesin pengayak, maka id mesin ini akan dikirim kan ke server untuk menentukan mesin mana yang akan di nyalakan.</strong>',
        trigger: 'mouseenter click',
        placement: 'bottom',
        allowHTML: true
    });
    </script>
<?php $__env->stopPush(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.guest', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/pbctmyid/laravel/resources/views/auth/register-owner.blade.php ENDPATH**/ ?>