<?php $__env->startSection('slot'); ?>
    <div class="login-wrapper w-full flex justify-center lg:items-center h-full">
        <div class="wrapper flex flex-col gap-10 lg:bg-white lg:border-2 lg:border-stone-300/40 w-max h-max p-6 rounded-xl">
            <div class="w-full">
                <form action="<?php echo e(route('login')); ?>" method="POST" class="flex flex-col gap-4 items-center">
                    <?php echo csrf_field(); ?>
                    <a href="<?php echo e(url('/')); ?>">
                        <img src="<?php echo e(asset('icons/icon-72x72.png')); ?>" class="scale-90">
                    </a>
                    <h1 class="text-2xl tracking-wide mb-10 lg:mb-0" style="font-weight: 700; font-variation-settings: 'wght' 700">LOGIN</h1>
                    <div class="flex flex-col gap-2">
                        <label for="username">Username</label>
                        <?php if (isset($component)) { $__componentOriginalef9fe90827f80191dcf8af8db4c01e3441ebe337 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\FillSpace::class, []); ?>
<?php $component->withName('fill-space'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
                            <input autocomplete-"off" id="username" class="h-10 w-68 pl-2 outline-none focus:border-sky-300 border-2 border-zinc-200 bg-zinc-200 rounded-md" type="text" name="username" placeholder="Masukkan username" required>
                         <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalef9fe90827f80191dcf8af8db4c01e3441ebe337)): ?>
<?php $component = $__componentOriginalef9fe90827f80191dcf8af8db4c01e3441ebe337; ?>
<?php unset($__componentOriginalef9fe90827f80191dcf8af8db4c01e3441ebe337); ?>
<?php endif; ?>
                    </div>
                    <div class="flex flex-col gap-2">
                        <label for="password">Kata sandi</label>
                        <?php if (isset($component)) { $__componentOriginal3844197888b5b4ca19a35b1dc5e2512383c87dee = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\PeekPassword::class, []); ?>
<?php $component->withName('peek-password'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
                            <input autocomplete-"off" id="password" class="h-10 w-68 pl-2 outline-none focus:border-sky-300 border-2 border-zinc-200 bg-zinc-200 rounded-md" type="password" name="password" placeholder="Masukkan kata sandi" required>
                         <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal3844197888b5b4ca19a35b1dc5e2512383c87dee)): ?>
<?php $component = $__componentOriginal3844197888b5b4ca19a35b1dc5e2512383c87dee; ?>
<?php unset($__componentOriginal3844197888b5b4ca19a35b1dc5e2512383c87dee); ?>
<?php endif; ?>
                    </div>
                    <?php if($errors->any()): ?>
                        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <p class="text-xs text-red-500" id="error-machine-id"><?php echo e($error); ?></p>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php endif; ?>
                    <button type="submit" class="active:bg-sky-300 active:text-sky-600 bg-sky-200 text-sky-500 font-bold w-36 h-10 rounded-lg">Login</button>
                    
                    <p class="text-xs " id="error-machine-id">Anda seorang Owner dan belum memiliki akun?<br>hubungi admin atau <a class="text-sky-500" href="<?php echo e(route('register-owner')); ?>">register secara mandiri</a></p>
                </form>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.guest', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH A:\aufa\MYREPOS\sistem_papbct\resources\views/auth/login.blade.php ENDPATH**/ ?>