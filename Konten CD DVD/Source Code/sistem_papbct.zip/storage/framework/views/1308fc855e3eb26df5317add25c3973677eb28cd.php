<?php $__env->startSection('slot'); ?>
    <?php $__env->startPush('top'); ?>
        <h1 style="font-weight: 800;"><?php echo e(__('Pengaturan')); ?></h1>
        <p class="text-xs hidden">ID mesin : <span id="machine-id-value"><?php echo e(isset($machineid) ? $machineid : 'belum terhubung'); ?></span></p>
        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <p class="text-xs text-red-500 text-center" id="error-password-change"><?php echo e($error); ?></p>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <?php $__env->stopPush(); ?>
    <div class="settings w-full lg:mt-4 flex lg:items-start justify-center items-center flex-col lg:flex-row gap-2">
        <div class="wrapper flex flex-col bg-zinc-100 w-max h-max p-6 rounded-xl">
            <span class="text-lg font-bold text-center"><?php echo e(auth()->user()->role == 'owner' ? 'AKUN DAN MESIN' : 'GANTI KATA SANDI'); ?></span>
            <div class="machine-setting w-full flex justify-center mt-5">
                <?php if(auth()->user()->role == 'owner'): ?>
                    <form action="<?php echo e(route('bond')); ?>" method="POST" class="flex flex-col gap-4 items-center">
                        <?php echo csrf_field(); ?>
                        <div class="flex flex-col gap-2">
                            <?php if (isset($component)) { $__componentOriginalee2301e75258d546ded542aad400c79e399d91cc = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\HelpTooltip::class, []); ?>
<?php $component->withName('help-tooltip'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
                                <label for="machineid-label">ID mesin</label>
                             <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalee2301e75258d546ded542aad400c79e399d91cc)): ?>
<?php $component = $__componentOriginalee2301e75258d546ded542aad400c79e399d91cc; ?>
<?php unset($__componentOriginalee2301e75258d546ded542aad400c79e399d91cc); ?>
<?php endif; ?>
                            <?php if (isset($component)) { $__componentOriginal3844197888b5b4ca19a35b1dc5e2512383c87dee = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\PeekPassword::class, []); ?>
<?php $component->withName('peek-password'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
                                <input class="disabled:bg-zinc-400 invalid:border-red-500 h-10 w-68 pl-2 outline-none focus:border-sky-300 border-2 border-zinc-200 bg-zinc-200 rounded-md" type="password" name="machineid" placeholder="masukkan id mesin" required <?php echo e(isset($machineid) ? 'readonly' : ''); ?> value="<?php echo e($machineid == null ? '' : $machineid); ?>">
                             <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal3844197888b5b4ca19a35b1dc5e2512383c87dee)): ?>
<?php $component = $__componentOriginal3844197888b5b4ca19a35b1dc5e2512383c87dee; ?>
<?php unset($__componentOriginal3844197888b5b4ca19a35b1dc5e2512383c87dee); ?>
<?php endif; ?>
                            <input type="hidden" name="option" value="<?php echo e($machineid == null ? 'bind' : 'unbind'); ?>">
                            <?php if(Session::has('failed')): ?>
                                <p class="text-xs text-red-500" id="error-machine-id"><?php echo e(Session::get('failed')); ?></p>
                                <?php
                                    Session::forget('failed');
                                ?>
                            <?php endif; ?>
                            <?php if(Session::has('success')): ?>
                            <p class="text-xs text-green-500" id="success-machine-id"><?php echo e(Session::get('success')); ?></p>
                                <?php
                                    Session::forget('success');
                                ?>
                            <?php endif; ?>
                        </div>
                        <button class="font-bold w-36 h-10 rounded-lg active:bg-sky-300 active:text-sky-600 bg-sky-200 text-sky-500" type="submit"><?php echo e(isset($machineid) ? 'Hapus' : 'Simpan ID'); ?></button>
                    </form>
                <?php endif; ?>
            </div>
            <div class="account-setting w-full mt-5">
                <form action="<?php echo e(route('changepassword')); ?>" method="POST" class="flex flex-col gap-4 items-center">
                    <?php echo csrf_field(); ?>
                    <div class="flex flex-col gap-2">
                        <label for="current_password">Kata sandi lama</label>
                        <?php if (isset($component)) { $__componentOriginal3844197888b5b4ca19a35b1dc5e2512383c87dee = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\PeekPassword::class, []); ?>
<?php $component->withName('peek-password'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
                            <input id="current_password" class="h-10 w-68 pl-2 outline-none focus:border-sky-300 border-2 border-zinc-200 bg-zinc-200 rounded-md" type="password" name="current_password" placeholder="masukkan sandi lama" required>
                            <?php if(Session::has('change-success')): ?>
                                <p class="text-xs text-green-500" id="success-password-change"><?php echo e(Session::get('change-success')); ?></p>
                            <?php endif; ?>
                            <?php
                                Session::forget('change-success');
                            ?>
                         <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal3844197888b5b4ca19a35b1dc5e2512383c87dee)): ?>
<?php $component = $__componentOriginal3844197888b5b4ca19a35b1dc5e2512383c87dee; ?>
<?php unset($__componentOriginal3844197888b5b4ca19a35b1dc5e2512383c87dee); ?>
<?php endif; ?>
                    </div>
                    <div class="flex flex-col gap-2">
                        <label for="new_password">Kata sandi baru</label>
                        <?php if (isset($component)) { $__componentOriginal3844197888b5b4ca19a35b1dc5e2512383c87dee = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\PeekPassword::class, []); ?>
<?php $component->withName('peek-password'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
                            <input id="new_password" class="h-10 w-68 pl-2 outline-none focus:border-sky-300 border-2 border-zinc-200 bg-zinc-200 rounded-md" type="password" name="new_password" required placeholder="masukkan sandi baru">
                         <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal3844197888b5b4ca19a35b1dc5e2512383c87dee)): ?>
<?php $component = $__componentOriginal3844197888b5b4ca19a35b1dc5e2512383c87dee; ?>
<?php unset($__componentOriginal3844197888b5b4ca19a35b1dc5e2512383c87dee); ?>
<?php endif; ?>
                    </div>
                    <button type="submit" class="active:bg-sky-300 active:text-sky-600 bg-sky-200 text-sky-500 font-bold w-36 h-10 rounded-lg">Simpan Sandi</button>
                </form>
            </div>
        </div>
        <?php if(auth()->user()->role == 'owner'): ?>
            <div class="wrapper flex flex-col bg-zinc-100 w-max h-max p-6 rounded-xl">
                <span class="text-lg font-bold text-center">DATA AKUN PEKERJA</span>
                <form action="<?php echo e(route('registerpekerjafromowner')); ?>" method="post" class="flex flex-col gap-4 items-center mt-5">
                    <?php echo csrf_field(); ?>
                    <div class="flex flex-col gap-2">
                        <label for="pekerja_username">Username</label>
                        <?php if (isset($component)) { $__componentOriginalef9fe90827f80191dcf8af8db4c01e3441ebe337 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\FillSpace::class, []); ?>
<?php $component->withName('fill-space'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
                            <input id="pekerja_username" class="h-10 w-68 pl-2 outline-none focus:border-sky-300 border-2 border-zinc-200 bg-zinc-200 rounded-md" type="text" name="pekerja_username" required placeholder="username pekerja">
                         <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalef9fe90827f80191dcf8af8db4c01e3441ebe337)): ?>
<?php $component = $__componentOriginalef9fe90827f80191dcf8af8db4c01e3441ebe337; ?>
<?php unset($__componentOriginalef9fe90827f80191dcf8af8db4c01e3441ebe337); ?>
<?php endif; ?>
                    </div>
                    <div class="flex flex-col gap-2">
                        <label for="pekerja_password">Kata sandi</label>
                        <?php if (isset($component)) { $__componentOriginal3844197888b5b4ca19a35b1dc5e2512383c87dee = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\PeekPassword::class, []); ?>
<?php $component->withName('peek-password'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
                            <input id="pekerja_password" class="h-10 w-68 pl-2 outline-none focus:border-sky-300 border-2 border-zinc-200 bg-zinc-200 rounded-md" type="password" name="pekerja_password" required placeholder="sandi pekerja">
                         <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal3844197888b5b4ca19a35b1dc5e2512383c87dee)): ?>
<?php $component = $__componentOriginal3844197888b5b4ca19a35b1dc5e2512383c87dee; ?>
<?php unset($__componentOriginal3844197888b5b4ca19a35b1dc5e2512383c87dee); ?>
<?php endif; ?>
                    </div>
                    <?php if(Session::has('owner-settings-pekerja-success')): ?>
                        <p class="text-xs text-green-500"><?php echo e(Session::get('owner-settings-pekerja-success')); ?></p>
                        <?php
                            Session::forget('owner-settings-pekerja-success');
                        ?>
                    <?php elseif(Session::has('owner-settings-pekerja-failed')): ?>
                        <p class="text-xs text-green-500"><?php echo e(Session::get('owner-settings-pekerja-failed')); ?></p>
                        <?php
                            Session::forget('owner-settings-pekerja-failed');
                        ?>
                    <?php endif; ?>
                    <button type="submit" class="active:bg-sky-300 active:text-sky-600 bg-sky-200 text-sky-500 font-bold w-36 h-10 rounded-lg">Simpan Data</button>
                </form>
                <div class="flex justify-center flex-col mt-5">
                    <table class="table text-sm border border-black/20 text-center">
                        <thead class="border border-black/20">
                            <tr>
                                <th class="border border-black/20">#</th>
                                <th class="border border-black/20">Nama</th>
                                <th class="border border-black/20">Hapus</th>
                            </tr>
                        </thead>
                        <tbody class="border-collapse">
                            <?php $__currentLoopData = $employees; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $employee): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td class="border border-black/20"><?php echo e($loop->iteration); ?></td>
                                    <td class="border border-black/20"><?php echo e($employee->username); ?></td>
                                    <td class="flex gap-3 justify-center border border-black/20">
                                        <div title="reset password" id="reset-password-pekerja" class="cursor-pointer" onclick="toggleModalResetPasswordPekerja(<?php echo e($employee->id); ?>)">
                                            <svg width="24" height="24" fill="none" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg"><path d="M7.207 2.543a1 1 0 0 1 0 1.414L5.414 5.75h7.836a8 8 0 1 1-8 8 1 1 0 1 1 2 0 6 6 0 1 0 6-6H5.414l1.793 1.793a1 1 0 0 1-1.414 1.414l-3.5-3.5a1 1 0 0 1 0-1.414l3.5-3.5a1 1 0 0 1 1.414 0Z" fill="#0284c7"/></svg>
                                        </div>
                                        <div id="hapus-pekerja" title="Hapus" class="cursor-pointer" onclick="this.firstElementChild.submit()">
                                            <form action="<?php echo e(route('deletepekerja')); ?>" method="post">
                                                <?php echo csrf_field(); ?>
                                                <input type="hidden" name="pekerja_id" value="<?php echo e($employee->id); ?>">
                                            </form>
                                            <svg class="fill-red-500" width="24" height="24" fill="none" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg"><path d="M21.5 6a1 1 0 0 1-.883.993L20.5 7h-.845l-1.231 12.52A2.75 2.75 0 0 1 15.687 22H8.313a2.75 2.75 0 0 1-2.737-2.48L4.345 7H3.5a1 1 0 0 1 0-2h5a3.5 3.5 0 1 1 7 0h5a1 1 0 0 1 1 1Zm-7.25 3.25a.75.75 0 0 0-.743.648L13.5 10v7l.007.102a.75.75 0 0 0 1.486 0L15 17v-7l-.007-.102a.75.75 0 0 0-.743-.648Zm-4.5 0a.75.75 0 0 0-.743.648L9 10v7l.007.102a.75.75 0 0 0 1.486 0L10.5 17v-7l-.007-.102a.75.75 0 0 0-.743-.648ZM12 3.5A1.5 1.5 0 0 0 10.5 5h3A1.5 1.5 0 0 0 12 3.5Z"/></svg>
                                        </div>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>
        <?php endif; ?>
    </div>
    <div class="mb-20 lg:hidden">
        <div class="w-1 h-32"></div>
    </div>
<?php $__env->startPush('scripts'); ?>
    <script>
    tippy('#help-id-mesin', {
        content: '<strong style="color: #F5C642;">ID mesin</strong> digunakan untuk menghubungkan akun Anda dengan mesin pembuat bubuk cangkang telur anda. <br><br>Misalnya Anda atau pekerja yang anda punya ingin menyalakan mesin pengayak, maka id mesin ini akan dikirim kan ke server untuk menentukan mesin mana yang akan di nyalakan.</strong>',
        trigger: 'mouseenter click',
        placement: 'bottom',
        allowHTML: true
    });
    </script>
<?php $__env->stopPush(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH A:\aufa\MYREPOS\sistem_papbct\resources\views/settings.blade.php ENDPATH**/ ?>